# pipelineresources
cp4i pipeline resources for ace and mq
